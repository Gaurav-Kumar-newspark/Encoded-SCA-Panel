$(function(e) {
	$('.content5').richText();
	$('.content2').richText();
});