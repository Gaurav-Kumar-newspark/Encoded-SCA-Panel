(function($) {
	"use strict";
	
	//P-scrolling
	
	
	const ps2 = new PerfectScrollbar('.chat-scroll', {
	  useBothWheelAxes:false,
	  suppressScrollX:false,
	});
	const ps3 = new PerfectScrollbar('.Notification-scroll', {
	  useBothWheelAxes:false,
	  suppressScrollX:false,
	});
	
	
	
})(jQuery);